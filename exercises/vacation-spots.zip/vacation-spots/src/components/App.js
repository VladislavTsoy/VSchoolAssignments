import React from 'react'
import CardBox from './CardBox'

const App = () => {
    return (
        <div>
            <CardBox />
        </div>
    )
}

export default App